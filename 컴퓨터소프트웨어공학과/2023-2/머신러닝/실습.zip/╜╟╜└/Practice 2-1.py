print(12+37)
print('python'+'is exciting')

import random

a=random.randint(10,20)
b=random.randint(10,20)

c=a+b
print(a,b,c)