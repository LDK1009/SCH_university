#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>


int pow(int x, int n);

int main(void) {
	int x = 0, n = 0;
	printf("x >> ");
	scanf("%d", &x);
	printf("n >> ");
	scanf("%d", &n);

	printf("%d^%d�� ��� : %d", x, n, pow(x, n));
}

int pow(int x, int n) {
	int return_value = 1;
	if (n == 0)
	{
		return 1;
	}
	else
	{
		for (int i = 1; i <= n; i++) {
			return_value *= x;
		}
		return return_value;
	}
}