#include <stdio.h>

int main(void) {
	int a = 10, b = 20;


	void CBV(int a, int b);
	void CBA(int* a, int* b);

	printf("a = %d b = %d, ", a, b);
	CBV(a, b);
	printf("�� : %d", a);
	printf("\n");

	a = 10;
	printf("a = %d b = %d, ", a, b);
	CBA(&a, &b);
	printf("�� : %d", a);
	printf("\n");

	return 0;
}

void CBV(int a, int b) {
	a = a + b;
}

void CBA(int* a, int* b) {
	*a = *a + *b;
}