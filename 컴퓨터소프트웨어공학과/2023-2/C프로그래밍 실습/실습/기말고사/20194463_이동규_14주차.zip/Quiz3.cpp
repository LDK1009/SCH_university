#define _CRT_SECURE_NO_WARNINGS
#define _USE_MATH_DEFINES
#include <stdio.h>
#include <math.h>

void calDiameter(float*, float* );
void calRound(float*, float*);
void calArea(float*, float*);

int main(void) {
    float r;
    float calResult;
    int option;
    void (*fpary[3])(float*, float*) = { calDiameter, calRound, calArea };


    printf("������>>");
    scanf("%f", &r);
    printf("0.���� 1.�ѷ� 2.���� \n >>");
    scanf("%d", &option);
    switch (option)
    {
    case 0:
        fpary[0](&r, &calResult);
        break;
    case 1:
        fpary[1](&r, &calResult);
        break;
    case 2:
        fpary[2](&r, &calResult);
        break;
    default:
        printf("�ɼ� ����");
        break;
    }

    return 0;
}

void calDiameter(float* radius, float* result) {
    *result = 2 * *radius;
    printf("��� : %f", *result);
}

void calRound(float* radius, float* result) {
    *result = 2 * M_PI* *radius;
    printf("��� : %f", *result);
}

void calArea(float* radius, float* result) {
    *result = M_PI* *radius * *radius;
    printf("��� : %f", *result);
}