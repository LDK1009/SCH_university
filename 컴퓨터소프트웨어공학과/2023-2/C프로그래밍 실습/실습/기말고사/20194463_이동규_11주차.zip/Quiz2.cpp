#include <stdio.h>

int main() {
    char str[] = "abcdefg";
    printf("\n");
    // char �迭
    printf("���ڿ� : %s\n-char(1byte)-\n", str);
    for (int i = 0; i <= 7; i++) {
        printf("[%d]: %c(0x%02x)\n", i, str[i], str[i]);
    }
    printf("\n");
    // short �迭
    short* shortPtr = (short*)str;
    printf("-short(2byte)-\n");
    for (int i = 0; i < 4; i++) {
        printf("[%d]: %d(0x%04x)\n", i, shortPtr[i], shortPtr[i]);
    }
    printf("\n");
    // int �迭
    int* intPtr = (int*)str;
    printf("-int(4byte)-\n");
    for (int i = 0; i < 2; i++) {
        printf("[%d]: %d(0x%08x)\n", i, intPtr[i], intPtr[i]);
    }
    printf("\n");
    // long �迭
    long* longPtr = (long*)str;
    printf("-long(8byte)-\n");
    for (int i = 0; i < 1; i++) {
        printf("[%d]: %ld(0x%016lx)\n", i, longPtr[i], longPtr[i]);
    }
    printf("\n");
    // long long �迭
    long long* longLongPtr = (long long*)str;
    printf("-long long(8byte)-\n");
    for (int i = 0; i < 1; i++) {
        printf("[%d]: %lld(0x%016llx)\n", i, longLongPtr[i], longLongPtr[i]);
    }
    printf("\n");
    return 0;
}
