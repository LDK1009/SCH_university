#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void) {
	double data = 10.1;

	printf("�ּ�:%p ũ��:%zu �Է°�:%f", &data, sizeof(&data), data);
	return 0;
}