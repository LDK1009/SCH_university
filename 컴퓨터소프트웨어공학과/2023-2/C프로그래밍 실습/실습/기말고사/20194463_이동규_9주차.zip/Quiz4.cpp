#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
	int randomNumber = 0;
	int arr1[5][5];
	int arr2[5][5];
	int sum_arr[5][5];


	// �迭1 �ʱ�ȭ
	printf("\n");
	printf("1�� �迭 \n");
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			randomNumber = rand();
			arr1[i][j] = randomNumber;
			printf("%d \t", arr1[i][j]);
		}
		printf("\n");
	}

	// �迭2 �ʱ�ȭ
	printf("\n");
	printf("2�� �迭 \n");
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			randomNumber = rand();
			arr2[i][j] = randomNumber;
			printf("%d \t", arr2[i][j]);
		}
		printf("\n");

	}

	//�� �迭�� ��
	printf("\n");
	printf("�� �迭�� �� \n");
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			randomNumber = rand();
			sum_arr[i][j] = arr1[i][j] + arr2[i][j];
			printf("%d \t", sum_arr[i][j]);
		}
		printf("\n");

	}

	system("pause");
	return 0;
}

