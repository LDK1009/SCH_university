#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define ROW 4
#define COL 4

int arr[ROW][COL] =
{
	{12, 56, 32, 16},
	{98, 99, 56, 34},
	{41, 3, 65, 3},
	{87, 78, 21, 85},
};

int main(void) {
	int RowSum(int row);
	int ColSum(int col);

	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			printf("%d \t", arr[i][j]);
		}
		printf("\n");
	}

	printf("\n");

	for (int i = 0; i < 4; i++)
	{
		printf("%d ���� �� : %d \t", i, RowSum(i));
		printf("%d ���� �� : %d \t", i, ColSum(i));
		printf("\n");
	}

	return 0;
}

//���� ��
int RowSum(int row) {
	int row_sum = 0;
	for (int i = 0; i < COL; i++)
	{
		row_sum += arr[row][i];
	}

	return row_sum;
}

//���� ��
int ColSum(int col) {
	int col_sum = 0;
	for (int i = 0; i < ROW; i++)
	{
		col_sum += arr[i][col];
	}

	return col_sum;
}