#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
	int arr[20];
	int arr_size = sizeof(arr) / sizeof(arr[0]);
	int random_number = 0;
	int sum = 0, min = 0, max=0;

	// ���� ����
	for (int i = 0; i < arr_size; i++)
	{
		random_number = rand();
		arr[i] = random_number;
		printf("%d \n", arr[i]);
	}

	// �� ���ϱ�
	for (int i = 0; i < arr_size; i++)
	{
		sum += arr[i];
	}

	//�ִ밪 ���ϱ�
	for (int i = 0; i < arr_size; i++)
	{
		max = (arr[i] > arr[i + 1]) ? arr[i] : arr[i + 1];
	}


	//�ּڰ� ���ϱ�
	for (int i = 0; i < arr_size; i++)
	{
		min = (arr[i] < arr[i + 1]) ? arr[i] : arr[i + 1];
	}

	printf("�迭�� ���� %d \n", sum);
	printf("�ִ밪�� %d \n", max);
	printf("�ּҰ��� %d \n", min);
}
