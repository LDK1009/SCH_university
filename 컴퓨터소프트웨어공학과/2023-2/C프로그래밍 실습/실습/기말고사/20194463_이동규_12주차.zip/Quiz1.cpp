#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


int main(void) {
	char inputStr[1024] = "";
	int i = 0;

	while (true)
	{
		printf("���� �Է�(���� : q) >> ");
		scanf("%s", &inputStr);

		if (*inputStr == 'q')
		{
			printf("���α׷� ���� ");
			break;
		}


		printf("�ܾ� %d : %s, ", i, inputStr);
		printf("%s, ", _strlwr(inputStr));
		printf("%s ", _strupr(inputStr));
		printf("\n\n");
		i += 1;
	}


	return 0;
}

