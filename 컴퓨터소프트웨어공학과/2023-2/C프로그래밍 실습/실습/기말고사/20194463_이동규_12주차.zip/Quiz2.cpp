#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


int main(void) {
	char inputStr[1024] = "";
	printf("���� �Է� >> ");
	scanf("%s", &inputStr);


	printf("���� : ");
	for (int i = strlen(inputStr); i >= 0; i--)
	{
		printf("%c", inputStr[i]);
	}


	return 0;
}

