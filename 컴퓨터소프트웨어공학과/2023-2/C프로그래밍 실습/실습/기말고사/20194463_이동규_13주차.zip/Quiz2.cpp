#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

union MyUnion
{
	char ch;
	int d;
};
typedef union MyUnion MyUnion;

int main(void)
{
	MyUnion Mydata;
	scanf("%c", &Mydata.ch);
	printf("a: %c b: %d \n", Mydata.ch, Mydata.d);
	scanf("%d", &Mydata.d);
	printf("a: %c b: %d \n", Mydata.ch, Mydata.d);
}