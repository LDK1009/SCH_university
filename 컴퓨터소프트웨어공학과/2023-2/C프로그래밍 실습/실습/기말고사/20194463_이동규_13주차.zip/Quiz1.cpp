#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

struct Identity
{
	char name[12];
	int year;
	int month;
	int day;
};

struct group
{
	struct Identity person1;
	struct Identity person2;
	struct Identity person3;
};

int main(void)
{
	struct group group1;
	printf("3���� �̸��� ��������� �Է¹����ÿ� \n");
	scanf("%s %d %d %d", &group1.person1.name, &group1.person1.year, &group1.person1.month, &group1.person1.day);
	scanf("%s %d %d %d", &group1.person2.name, &group1.person2.year, &group1.person2.month, &group1.person2.day);
	scanf("%s %d %d %d", &group1.person3.name, &group1.person3.year, &group1.person3.month, &group1.person3.day);

	printf("\n");
	printf("�̸� : %s ������� : %d-%d-%d \n", group1.person1.name, group1.person1.year, group1.person1.month, group1.person1.day);
	printf("�̸� : %s ������� : %d-%d-%d \n", group1.person2.name, group1.person2.year, group1.person2.month, group1.person2.day);
	printf("�̸� : %s ������� : %d-%d-%d \n", group1.person3.name, group1.person3.year, group1.person3.month, group1.person3.day);




	return 0;

}