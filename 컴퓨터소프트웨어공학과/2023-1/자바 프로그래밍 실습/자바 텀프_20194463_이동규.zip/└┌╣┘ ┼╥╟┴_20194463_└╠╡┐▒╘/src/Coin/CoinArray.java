package Coin;

import java.util.ArrayList;
import java.util.List;

public class CoinArray {
	public static List<Coin> coinList = new ArrayList<Coin>();
}

