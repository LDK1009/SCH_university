package Can;

import java.util.ArrayList;
import java.util.List;

public class CanArray {
    public static List<Can> canList = new ArrayList<Can>();
}
