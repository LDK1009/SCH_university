int sum(int n)
{
	int temp = 0;
	for (int i = 0; i < n; i++)
		temp += i;
	return temp;
}