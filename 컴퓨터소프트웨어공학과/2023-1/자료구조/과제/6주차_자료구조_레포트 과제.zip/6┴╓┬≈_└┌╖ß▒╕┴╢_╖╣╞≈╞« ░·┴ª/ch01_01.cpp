change(A, B)
temp <- A
A <- B
B <- temp
return (A, B)