typedef struct complex
{
	float real, imaginary;
} complex;

int main()
{
	complex c1, c1;
	return 0;
}